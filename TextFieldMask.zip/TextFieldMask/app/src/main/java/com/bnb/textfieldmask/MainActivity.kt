package com.bnb.textfieldmask

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.bnb.textfieldmask.ui.theme.TextFieldMaskTheme
import com.santalu.maskara.Mask
import com.santalu.maskara.MaskChangedListener
import com.santalu.maskara.MaskStyle

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TextFieldMaskTheme {
                FormScreen()
            }
        }
    }
}

@Composable
fun FormScreen() {
    var phone by remember {
        mutableStateOf("")
    }
    var cpf by remember {
        mutableStateOf("")
    }
    Column {
        TextField(
            value = phone,
            onValueChange = {
                if (it.length < 12){
                    phone = it
                }
            },
            Modifier
                .padding(8.dp)
                .fillMaxWidth(),
            label = {
                Text(text = "Telefone")
            },
            visualTransformation = PhoneMaskTransformation()
        )
        Spacer(modifier = Modifier.height(16.dp))
        TextField(
            value = cpf,
            onValueChange = {
                if (it.length < 12){
                    cpf = it
                }
            },
            Modifier
                .padding(8.dp)
                .fillMaxWidth(),
            label = {
                Text(text = "Cpf")
            },
            visualTransformation = CpfMaskTransformation()
        )
    }
}

//+55 (99) 99999-9999
class PhoneMaskTransformation : VisualTransformation {

    val mask = Mask(
        value = "+55 (__) _____-____",
        character = '_',
        style = MaskStyle.NORMAL
    )
    override fun filter(phone: AnnotatedString): TransformedText {

        val characterMask = mask.character.toString()
        val listener = MaskChangedListener(mask)
        val unMaskedText = phone.text

        if (unMaskedText == "") {
            return TransformedText(
                AnnotatedString(unMaskedText),
                PhoneOffsetKMapping
            )
        }

        listener.onTextChanged(unMaskedText, 0, 1, 0)

        val maskedText = listener.masked
        val array = Array(maskedText.length) { maskedText[it].toString() }
        val indexMask = array.indexOfFirst { it == characterMask }.takeIf { it != -1 } ?: array.size

        setIndexMask(indexMask)

        return TransformedText(
            AnnotatedString(maskedText),
            PhoneOffsetKMapping
        )
    }

    companion object PhoneOffsetKMapping : OffsetMapping {

        private var indexMask = 0

        fun setIndexMask(indexMask: Int) {
            this.indexMask = indexMask
        }

        override fun originalToTransformed(offset: Int): Int {
            return indexMask
        }

        override fun transformedToOriginal(offset: Int): Int {
            return indexMask
        }
    }
}

//999.999.999-99
class CpfMaskTransformation : VisualTransformation {

    val mask = Mask(
        value = "___.___.___-__",
        character = '_',
        style = MaskStyle.NORMAL
    )
    override fun filter(cpf: AnnotatedString): TransformedText {

        val characterMask = mask.character.toString()
        val listener = MaskChangedListener(mask)
        val unMaskedText = cpf.text

        if (unMaskedText == "") {
            return TransformedText(
                AnnotatedString(unMaskedText),
                CpfOffsetKMapping
            )
        }

        listener.onTextChanged(unMaskedText, 0, 1, 0)

        val maskedText = listener.masked
        val array = Array(maskedText.length) { maskedText[it].toString() }
        val indexMask = array.indexOfFirst { it == characterMask }.takeIf { it != -1 } ?: array.size

        setIndexMask(indexMask)

        return TransformedText(
            AnnotatedString(maskedText),
            CpfOffsetKMapping
        )
    }

    companion object CpfOffsetKMapping : OffsetMapping {

        private var indexMask = 0

        fun setIndexMask(indexMask: Int) {
            this.indexMask = indexMask
        }

        override fun originalToTransformed(offset: Int): Int {
            return indexMask
        }

        override fun transformedToOriginal(offset: Int): Int {
            return indexMask
        }
    }
}

